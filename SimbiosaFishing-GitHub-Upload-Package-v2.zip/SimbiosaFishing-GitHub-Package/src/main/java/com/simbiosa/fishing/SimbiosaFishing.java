package com.simbiosa.fishing;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.NamespacedKey;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

public final class SimbiosaFishing extends JavaPlugin implements Listener {
    private final Map<String, FishDefinition> fish = new LinkedHashMap<>();
    private Economy economy;
    private final Map<String, ConfigurationSection> baits = new LinkedHashMap<>();
    private final Map<String, ConfigurationSection> rods = new LinkedHashMap<>();
    private NamespacedKey fishKey, baitKey, rodKey;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        fishKey = new NamespacedKey(this, "fish_id");
        baitKey = new NamespacedKey(this, "bait_id");
        rodKey = new NamespacedKey(this, "rod_id");
        saveResource("fish.yml", false);
        saveResource("rods.yml", false);
        saveResource("baits.yml", false);
        saveResource("rewards.yml", false);
        loadDefinitions();
        setupEconomy();
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("SimbiosaFishing WIP enabled; fishing engine is basic vanilla-hook interception.");
    }

    public static String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text == null ? "" : text);
    }

    private void setupEconomy() {
        if (Bukkit.getPluginManager().getPlugin("Vault") == null) return;
        RegisteredServiceProvider<Economy> provider = getServer().getServicesManager().getRegistration(Economy.class);
        if (provider != null) economy = provider.getProvider();
    }

    private void loadDefinitions() {
        fish.clear();
        var config = org.bukkit.configuration.file.YamlConfiguration.loadConfiguration(
                new java.io.File(getDataFolder(), "fish.yml"));
        ConfigurationSection section = config.getConfigurationSection("fish");
        if (section == null) return;
        for (String id : section.getKeys(false)) {
            ConfigurationSection fishSection = section.getConfigurationSection(id);
            if (fishSection != null) fish.put(id, FishDefinition.from(id, fishSection));
        }
    }

    @EventHandler
    public void onFish(PlayerFishEvent event) {
        if (event.getState() != PlayerFishEvent.State.CAUGHT_FISH || !(event.getCaught() instanceof org.bukkit.entity.Item caught)) return;
        Player player = event.getPlayer();
        ItemStack baitStack = findBait(player);
        if (baitStack == null && !player.hasPermission("simbiosafish.bypass.bait")) {
            event.setCancelled(true);
            caught.remove();
            player.sendMessage(color(getConfig().getString("messages.need-bait", "&cKamu harus memakai Simbiosa Bait untuk mendapatkan ikan!")));
            return;
        }
        FishDefinition chosen = chooseFish();
        if (chosen == null) return;
        if (baitStack != null && !player.hasPermission("simbiosafish.bypass.bait")) {
            baitStack.setAmount(baitStack.getAmount() - 1);
        }
        event.setExpToDrop(0);
        caught.remove();
        ItemStack item = chosen.createItem(this, fishKey);
        Map<Integer, ItemStack> overflow = player.getInventory().addItem(item);
        overflow.values().forEach(stack -> player.getWorld().dropItemNaturally(player.getLocation(), stack));
        broadcastCatch(player.getName(), ChatColor.stripColor(color(chosen.name())), chosen.rarity());
    }

    private FishDefinition chooseFish() {
        List<FishDefinition> pool = fish.values().stream().filter(f -> f.enabled() && f.weight() > 0).toList();
        double total = pool.stream().mapToDouble(FishDefinition::weight).sum();
        if (total <= 0) return null;
        double roll = ThreadLocalRandom.current().nextDouble(total);
        for (FishDefinition f : pool) {
            roll -= f.weight();
            if (roll <= 0) return f;
        }
        return pool.get(pool.size() - 1);
    }

    public void broadcastCatch(String playerName, String fishName, String rarity) {
        if (!getConfig().getBoolean("broadcast.enabled", true)) return;
        String key = rarity.toUpperCase(Locale.ROOT);
        String path = "broadcast.rarity." + key;
        if (!getConfig().getBoolean(path + ".enabled", false)) return;
        String message = getConfig().getString(path + ".message", "");
        if (message == null || message.isBlank()) return;
        message = message.replace("{player}", playerName).replace("{fish}", fishName).replace("{rarity}", key);
        Bukkit.broadcastMessage(color(message));
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("fishadmin")) return handleAdmin(sender, args);
        if (command.getName().equalsIgnoreCase("fish")) return handleFish(sender, args);
        return false;
    }

    private boolean handleAdmin(CommandSender sender, String[] args) {
        if (!sender.hasPermission("simbiosafish.admin")) {
            sender.sendMessage(color(getConfig().getString("messages.no-permission", "&cNo permission.")));
            return true;
        }
        if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
            reloadConfig();
            loadDefinitions();
            sender.sendMessage(color(getConfig().getString("messages.reload-success", "&aReloaded.")));
            return true;
        }
        if (args.length >= 3 && args[0].equalsIgnoreCase("test")) {
            String rarity = args[1].toUpperCase(Locale.ROOT);
            String fishName = String.join(" ", Arrays.copyOfRange(args, 2, args.length));
            broadcastCatch(sender.getName(), fishName, rarity);
            return true;
        }
        if (args.length == 4 && args[0].equalsIgnoreCase("give")) {
            Player target = Bukkit.getPlayerExact(args[1]);
            String type = args[2].toLowerCase(Locale.ROOT);
            String id = args[3].toLowerCase(Locale.ROOT);
            ItemStack item = null;
            if (type.equals("fish") && fish.containsKey(id)) item = fish.get(id).createItem(this, fishKey);
            else if (type.equals("bait") && baits.containsKey(id)) item = createTaggedItem(Material.SLIME_BALL, baits.get(id), id, baitKey, "&aBait");
            else if (type.equals("rod") && rods.containsKey(id)) item = createTaggedItem(Material.FISHING_ROD, rods.get(id), id, rodKey, "&bRod");
            if (target == null || item == null) {
                sender.sendMessage(color("&cPemain atau ID item tidak ditemukan. Cek ID di fish.yml, baits.yml, rods.yml."));
                return true;
            }
            target.getInventory().addItem(item).values().forEach(extra -> target.getWorld().dropItemNaturally(target.getLocation(), extra));
            sender.sendMessage(color("&aItem Simbiosa diberikan."));
            return true;
        }
        sender.sendMessage(color("&e/fishadmin reload | test <RARITY> <nama ikan> | give <pemain> <fish|rod|bait> <id>"));
        return true;
    }

    private boolean handleFish(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }
        if (!player.hasPermission("simbiosafish.player")) {
            player.sendMessage(color(getConfig().getString("messages.no-permission", "&cNo permission.")));
            return true;
        }
        if (args.length == 0 || args[0].equalsIgnoreCase("menu")) {
            openMainMenu(player);
            return true;
        }
        if (args[0].equalsIgnoreCase("sellall")) {
            beginSell(player);
            return true;
        }
        if (args[0].equalsIgnoreCase("sell") && args.length >= 2) {
            if (args[1].equalsIgnoreCase("confirm")) confirmSell(player);
            else if (args[1].equalsIgnoreCase("cancel")) {
                pendingSales.remove(player.getUniqueId());
                player.sendMessage(color("&cPenjualan dibatalkan."));
            } else beginSell(player);
            return true;
        }
        if (args[0].equalsIgnoreCase("collection")) {
            player.sendMessage(color("&bFish Collection &7(" + fish.size() + " ikan terdaftar)"));
            fish.values().forEach(f -> player.sendMessage(color(f.name() + " &7- " + f.rarity())));
            return true;
        }
        if (args[0].equalsIgnoreCase("stats")) {
            player.sendMessage(color("&bSimbiosa Fishing &7| Statistik dan leaderboard akan ditambahkan pada iterasi berikutnya."));
            return true;
        }
        player.sendMessage(color(getConfig().getString("messages.usage", "&e/fish")));
        return true;
    }

    private void openMainMenu(Player player) {
        org.bukkit.inventory.Inventory inv = Bukkit.createInventory(null, 27, color("&0Simbiosa Fishing"));
        addButton(inv, 10, Material.FISHING_ROD, "&bRod Shop", List.of("&7Daftar rod akan dihubungkan pada tahap berikutnya."));
        addButton(inv, 12, Material.WHEAT_SEEDS, "&aBait Shop", List.of("&7Daftar bait akan dihubungkan pada tahap berikutnya."));
        addButton(inv, 14, Material.COD, "&fFish Collection", List.of("&7Lihat daftar ikan dengan /fish collection"));
        addButton(inv, 16, Material.GOLD_INGOT, "&6Sell Fish", List.of("&7Klik untuk memulai Sell All dengan konfirmasi."));
        player.openInventory(inv);
    }

    private void addButton(org.bukkit.inventory.Inventory inv, int slot, Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(color(name));
            meta.setLore(lore.stream().map(SimbiosaFishing::color).toList());
            item.setItemMeta(meta);
        }
        inv.setItem(slot, item);
    }

    private record PendingSale(List<ItemStack> items, double total, long expiresAt) {}
    private final Map<UUID, PendingSale> pendingSales = new HashMap<>();

    private void beginSell(Player player) {
        if (!player.hasPermission("simbiosafish.sell")) {
            player.sendMessage(color(getConfig().getString("messages.no-permission", "&cNo permission.")));
            return;
        }
        if (economy == null) {
            player.sendMessage(color(getConfig().getString("messages.vault-missing", "&cVault/economy missing.")));
            return;
        }
        List<ItemStack> items = new ArrayList<>();
        double total = 0;
        for (ItemStack stack : player.getInventory().getStorageContents()) {
            FishDefinition def = identifyFish(stack);
            if (def == null) continue;
            items.add(stack.clone());
            total += def.price() * stack.getAmount();
        }
        if (items.isEmpty()) {
            player.sendMessage(color(getConfig().getString("messages.sell-empty", "&eTidak ada ikan untuk dijual.")));
            return;
        }
        long expires = System.currentTimeMillis() + getConfig().getLong("settings.sell-confirmation-seconds", 15) * 1000;
        pendingSales.put(player.getUniqueId(), new PendingSale(items, total, expires));
        player.sendMessage(color(getConfig().getString("messages.sell-confirm",
                "&eJual {amount} ikan dengan total {price}? /fish sell confirm atau /fish sell cancel")
                .replace("{amount}", String.valueOf(items.stream().mapToInt(ItemStack::getAmount).sum()))
                .replace("{price}", String.format(Locale.US, "%.2f", total))));
    }

    private void confirmSell(Player player) {
        PendingSale sale = pendingSales.remove(player.getUniqueId());
        if (sale == null || sale.expiresAt() < System.currentTimeMillis()) {
            player.sendMessage(color(getConfig().getString("messages.sell-expired", "&cKonfirmasi kedaluwarsa.")));
            return;
        }
        // Verify matching quantities still exist before removing anything.
        Map<String, Integer> required = new HashMap<>();
        for (ItemStack stack : sale.items()) {
            FishDefinition def = identifyFish(stack);
            if (def != null) required.merge(def.id(), stack.getAmount(), Integer::sum);
        }
        Map<String, Integer> available = new HashMap<>();
        for (ItemStack stack : player.getInventory().getStorageContents()) {
            FishDefinition def = identifyFish(stack);
            if (def != null) available.merge(def.id(), stack.getAmount(), Integer::sum);
        }
        for (var entry : required.entrySet()) {
            if (available.getOrDefault(entry.getKey(), 0) < entry.getValue()) {
                player.sendMessage(color("&cInventory berubah. Penjualan dibatalkan, coba lagi."));
                return;
            }
        }
        for (ItemStack stack : player.getInventory().getStorageContents()) {
            FishDefinition def = identifyFish(stack);
            if (def == null) continue;
            int toRemove = required.getOrDefault(def.id(), 0);
            if (toRemove <= 0) continue;
            int remove = Math.min(toRemove, stack.getAmount());
            stack.setAmount(stack.getAmount() - remove);
            required.put(def.id(), toRemove - remove);
        }
        economy.depositPlayer(player, sale.total());
        player.sendMessage(color(getConfig().getString("messages.sell-success", "&aTerjual.")
                .replace("{amount}", String.valueOf(sale.items().stream().mapToInt(ItemStack::getAmount).sum()))
                .replace("{price}", String.format(Locale.US, "%.2f", sale.total()))));
    }

    private ItemStack findBait(Player player) {
        for (ItemStack stack : player.getInventory().getStorageContents()) {
            if (stack == null || !stack.hasItemMeta()) continue;
            String id = stack.getItemMeta().getPersistentDataContainer().get(baitKey, PersistentDataType.STRING);
            if (id != null && baits.containsKey(id)) return stack;
        }
        return null;
    }

    private ItemStack createTaggedItem(Material material, ConfigurationSection section, String id, NamespacedKey key, String label) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(color(section.getString("name", id)));
            meta.setLore(List.of(color("&7Rarity: &f" + section.getString("rarity", "COMMON")),
                    color("&7Harga: &6$" + section.getDouble("price", 0)),
                    color("&8Simbiosa " + label + ": " + id)));
            meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, id);
            item.setItemMeta(meta);
        }
        return item;
    }

    private FishDefinition identifyFish(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) return null;
        String id = stack.getItemMeta().getPersistentDataContainer().get(fishKey, PersistentDataType.STRING);
        return id == null ? null : fish.get(id);
    }
}
