package com.simbiosa.fishing;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.NamespacedKey;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;
import java.util.Locale;

public record FishDefinition(String id, String name, String rarity, double price, double weight, boolean enabled) {
    public static FishDefinition from(String id, ConfigurationSection section) {
        return new FishDefinition(
                id,
                section.getString("name", id),
                section.getString("rarity", "COMMON").toUpperCase(Locale.ROOT),
                section.getDouble("price", 0),
                section.getDouble("weight", 1),
                section.getBoolean("enabled", true)
        );
    }

    public ItemStack createItem(JavaPlugin plugin, NamespacedKey fishKey) {
        ItemStack item = new ItemStack(Material.COD);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(SimbiosaFishing.color(name));
            meta.setLore(List.of(
                    SimbiosaFishing.color("&7Rarity: &f" + rarity),
                    SimbiosaFishing.color("&7Harga jual: &6$" + String.format(Locale.US, "%.2f", price)),
                    SimbiosaFishing.color("&8ID: " + id)
            ));
            meta.getPersistentDataContainer().set(fishKey, PersistentDataType.STRING, id);
            item.setItemMeta(meta);
        }
        return item;
    }
}
